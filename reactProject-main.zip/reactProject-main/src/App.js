
import './App.css';
import Footer from './footer';

function App() {
  return (
    <div className="App">
      
      
      <header/>
      <Footer/>
    </div>
  );
}

export default App;
